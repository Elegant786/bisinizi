(function($){
    "use strict"
    
    //partner carosel 
    $('.partner-carousel1').owlCarousel({
        loop:true,
        nav:false,
        items:4,
        autoplay:true,
        autoplayTimeout:2000,
        autoplayHoverPause:true,
        dots:false,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:false
            },
            567:{
                items:2,
                margin:20
            },
            768:{
                items:3,
                margin:20
            },
            992:{
                items:4,
                margin:20
            }
        }

    });
    
//testimonial carousel  
   $('.testimonial-carousel1').owlCarousel({
        loop:true,
        nav:false,
        items:4,
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause:true,
        dots:true,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
            },
        }

    });  
    
    
//    team carousel
    
    $('.team-carousel1').owlCarousel({
        loop:true,
        nav:false,
        autoplay:false,
        dots:false,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
            },
            768:{
                items:2,
                margin:20,
            },
            992:{
                items:3,
                margin:20,
            },
        }

    });
    
//  feedback_carousel
       $('.feedback-carousel').owlCarousel({
        loop:true,
        navText:['<i class="fa fa-long-arrow-up" aria-hidden="true"></i>','<i class="fa fa-long-arrow-down" aria-hidden="true"></i>'],
        items:4,
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause:true,
        dots:true,
        responsiveClass:true,
        items:1,
        nav:true,
           dots:false,

    });  
    
  //  single portfolio_carousel
       $('.single-portfolio-carousel1').owlCarousel({
        loop:true,
        nav:true,
        navText:['<i class="fa fa-angle-left" aria-hidden="true"></i>','<i class="fa fa-angle-right" aria-hidden="true"></i>'],
        autoplay:false,
        dots:false,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:false,
                dots:true,
            },
            768:{
                items:1,
                nav:true,
                dots:false,
            }
        }

    });  
      
    
    
//    portfolio item1 instalation

$('.portfolio_item1').isotope({

  itemSelector: '.grid-item',
  percentPosition: true,
  masonry: {
    columnWidth: '.grid-item'
  }
});
 
    $('.filter li').on('click', function() {
		    $(this).addClass('active').siblings().removeClass('active');
		    var filterValue = $(this).attr('data-filter');
		    $('.grid').isotope({
		        filter: filterValue
		    });
		});
    
//    portfolio item2 instatation
    
    $('.portfolio_item2').isotope({

  itemSelector: '.grid-item',
  percentPosition: true,
  masonry: {
    columnWidth: '.grid-item'
  }
});
 
    $('.filter li').on('click', function() {
		    $(this).addClass('active').siblings().removeClass('active');
		    var filterValue = $(this).attr('data-filter');
		    $('.grid').isotope({
		        filter: filterValue
		    });
		});
    
    
    
    
//  banner area
    
      var wWidth = $(window).width();
    var wHight = $(window).height(),
        bannerSlider = $('#banner_slider2');


if (wWidth < 768) {
        if (bannerSlider.length) {
            bannerSlider.camera({
                height: 500 + 'px',
                loader: false,
                navigation: true,
                autoPlay: false,
                fx: 'scrollLeft',
                time: 4000,
                overlayer: true,
                playPause: false,
                pagination: false,
                thumbnails: false,
                onEndTransition: function () {
                    $('.cameraSlide img').addClass('grow');
                }
            });
        }
    }
    if (wWidth >= 768) {
        if (bannerSlider.length) {
            bannerSlider.camera({
                height: 700 + 'px',
                loader: false,
                navigation: true,
                autoPlay: false,
                fx: 'scrollLeft',
                time: 4000,
                overlayer: true,
                playPause: false,
                pagination: false,
                thumbnails: false,
                onEndTransition: function () {
                    $('.cameraSlide img').addClass('grow');
                }
            });
        }
    }
    
    
//    counter up installation 
    
    $('.counter').counterUp({
    delay: 10,
    time: 1000,
    offset: 70,
    beginAt: 100,
    formatter: function (n) {
      return n.replace(/,/g, '.');
    }
});
    
//count down

    
    
// google map install
    
    var googleMapSelector = $('#google-map'),
        myCenter = new google.maps.LatLng(51.5033640, -0.1276250);

    function initialize() {
        var mapProp = {
            center: myCenter,
            zoom: 15,
            scrollwheel: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: [
                {
                    "featureType": "administrative",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#444444"
                        }
                    ]
                },
                {
                    "featureType": "landscape",
                    "elementType": "all",
                    "stylers": [
                        {
                            "color": "#f2f2f2"
                        }
                    ]
                },
                {
                    "featureType": "poi",
                    "elementType": "all",
                    "stylers": [
                        {
                            "visibility": "off"
                        }
                    ]
                },
                {
                    "featureType": "road",
                    "elementType": "all",
                    "stylers": [
                        {
                            "saturation": -100
                        },
                        {
                            "lightness": 45
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "all",
                    "stylers": [
                        {
                            "visibility": "simplified"
                        }
                    ]
                },
                {
                    "featureType": "road.arterial",
                    "elementType": "labels.icon",
                    "stylers": [
                        {
                            "visibility": "off"
                        }
                    ]
                },
                {
                    "featureType": "transit",
                    "elementType": "all",
                    "stylers": [
                        {
                            "visibility": "off"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "all",
                    "stylers": [
                        {
                            "color": "#46bcec"
                        },
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#c8d7d4"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#ff0000"
                        }
                    ]
                }
            ]
        };
        var map = new google.maps.Map(document.getElementById("google-map"), mapProp);
        var marker = new google.maps.Marker({
            position: myCenter,
            animation: google.maps.Animation.BOUNCE,
            icon: 'assets/images/locator.png'
        });
        marker.setMap(map);
    }
    if (googleMapSelector.length) {
        google.maps.event.addDomListener(window, 'load', initialize);
    }
 
    
    
    
    
    
})(jQuery);