(function($) {
    "use strict";


        
    $('.menu_toggle').on('click',function(){
        $(this).siblings('.navbar-mobile').toggleClass('active');
    });

var myMenu = $('.navbar-nav > li');
        myMenu.children('ul').addClass('DropDown');
        var dropDown = $('.DropDown');
        var dropDownMenu = $('.DropDown').children('li');
        $('.DropDown').children('li').children('ul').addClass('subMenu');
        $('.subMenu').children('li').children('ul').addClass('NsubMenu');
        var subMenu = $('.subMenu');
            $('.DropDown').parent('li').addClass('DpSign');
            $('.subMenu').parent('li').addClass('DpSign');
            $('.NsubMenu').parent('li').addClass('DpSign');
        myMenu.on('click',function(ev){
            ev.preventDefault();
            $(this).children('.DropDown').slideToggle();
            $(this).siblings('li').children('.DropDown').slideUp();
            $('.subMenu').slideUp();
            $('.subMenu li ul').slideUp();
        });
        dropDownMenu.on('click',function(ev){
            ev.preventDefault();
            $(this).children('ul').slideToggle();
            ev.stopPropagation();
        });
        $('.subMenu li').on('click',function(ev){
            ev.preventDefault();
            $(this).children('ul').slideToggle();
            ev.stopPropagation();
        })


    $(document).mouseup(function (e) {
        var container = $(".navbar-nav,.DropDown,.subMenu,.NsubMenu,.modal-content,.offcanvas,.offra-dropdown.show");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            $('.DropDown').slideUp();
            $('.subMenu').slideUp();
            $(".NsubMenu").slideUp();
            $('.modal').removeClass('active');
            $('.modal').fadeOut();
            $(".offcanvas-overlay").remove();
            $(this).parent('.offcanvas').removeClass('show');
            $('body').removeClass('off-show');
            $('.offcanvas').removeClass('show');
            $('body').removeClass('offcanvas-push');
            $('.offra-dropdown').fadeOut();
            $('.offra-dropdown').removeClass('show');

        }

    });
var clicker = $('.tab-menu a');
        var atr = $('.tab-content').attr('id');
        var wrapper = $('.tabe-container');
        $('.tab-content').addClass('nodisplay')
        var allTabs = wrapper.find('div');
        var hoverable = $('.tab-menu.hoverable a');

        clicker.click(function (event) {
            event.preventDefault();
            $(this).parent().addClass('active');
            $(this).parent().siblings().removeClass('active');
            var result = $(this).attr('href');
            var newValue = result.replace('#', '');
            var shower = $('.tab-content[id*=' + newValue + ']').addClass('active');
            shower.siblings().removeClass('active');
        });

        if ($('.tab-menu').hasClass('hoverable')) {
            hoverable.on('mouseenter', function (event) {
                event.preventDefault();
                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');
                var result = $(this).attr('href');
                var newValue = result.replace('#', '');
                var shower = $('.tab-content[id*=' + newValue + ']').addClass('active');
                shower.siblings().removeClass('active');
            });
        }
    var toggleParent = $('.toggle-nav').children().find('ul').parent().addClass('down-sign');
    $('.toggle-nav').children().find('ul').slideUp();
    $('.toggle-nav').children('li').on('click',function(event){
        event.preventDefault();
        $(this).addClass('active');
        $(this).children('ul').slideToggle();
        $(this).siblings('li').children('ul').slideUp();
        $(this).siblings('li').removeClass('active');
    });
    
    $('.modal').fadeOut();
    var dModal = $('.modal');
    var Cmodal = document.getElementById('modal');
    var dModalcont = $('.modal-content');
       $('[data-modal-name]').on('click',function (event) {
            event.preventDefault();
            $(this).addClass('myModal');
            var current = ($(this).attr('data-modal-name'));
           console.log(current);
            var findModal = $(document).find("[data-target-modal='" + current + "']").fadeIn();
           
            $('.modal').addClass('active');
           if ($(".modal.active")[0]){
                $('html, body').css('overflowY', 'hidden');
            } 
        });
       $('.modal-cancel').on('click', function () {
            $('.modal').removeClass('active');
            $('.modal').fadeOut();
           $('html, body').css('overflowY', 'auto');
        });
//        $(window).click = function(event) {
//            
//
//            if (event.target == dModal) {
//                //dModal.style.display = "none";
//                console.log('outer modal');
//            }
//            if (event.target == dModalcont) {
//                //dModal.style.display = "none";
//                console.log('inner modal');
//            }
//        }
        $('.modal').on('click',function(){
            $('html, body').css('overflowY', 'auto');
        });
    
    $('.alert-cancel').on('click',function(){
        $(this).parent('.alert').hide();
    });
        
    //This code for collapse and Accordion    
    $('[data-collapse-panel]').hide();
    var acParent = $('.single-accordion');
    var showAc = $('.single-accordion.show');
        $('[data-collapse]').on('click',function (event) {
        event.preventDefault();
        var AcCurrent = ($(this).attr('href'));
        var acNew = AcCurrent.replace('#', '');
        $(this).parent('.single-accordion').toggleClass('show');
        var findAccordion = $(document).find("[id='" + acNew + "']").slideToggle();
        $(this).parent('.single-accordion').siblings().children('[data-collapse-panel]').slideUp();
        $(this).parent('.single-accordion').siblings().removeClass('show');
    });
    if($('.single-accordion').hasClass('show')){
       showAc.find('[data-collapse-panel]').slideDown();
    }
    $('.show-collapse').slideDown();
    
    
    
    $('[data-name]').on('click',function (event) {
        event.preventDefault();
        var AcCurrent = ($(this).attr('href'));
        var acNew = AcCurrent.replace('#', '');
        var ppData = "<div class='offcanvas-overlay'></div>";
        $(ppData).prependTo('body').fadeIn();
        setTimeout(function(){
           $('body').addClass('off-show');
       }, 10);    
        var findAccordion = $(document).find("[id='" + acNew + "']").addClass('show');
        if($('.offcanvas.show').hasClass('offcanvas-push')){
            $('body').addClass('offcanvas-push');
        }

    });
    $('.offcanvas-cancel').on('click',function(){
        $(this).parent('.offcanvas').removeClass('show');
        $('body').removeClass('off-show');
        $('body').removeClass('offcanvas-push');
        $(".offcanvas-overlay").remove();
    });
   
    
    /*tooltip*/
    
     $('.tooltiptext').hide();
    $('.tooltip').on('mouseenter',function(){
        var string =this.innerHTML;
        var position = this.dataset.tooltipposition;
        var text= this.dataset.tooltiptext;
        string+='<span class="tooltiptext tooltiptext_'+position+'"><span class="text">'+text+'</span></span>';
        this.classList.add('tooltip_'+position);
        this.innerHTML=string;
        $(this).children('.tooltiptext').show(100);
    }).on('mouseleave',function(){
        $(this).children('.tooltiptext').hide();
        $(this).children('.tooltiptext').remove();
        var position = this.dataset.tooltipposition;
        this.classList.remove('tooltip_'+position);
    });
    
    
   
    $(window).on('scroll',function(){
//        var stOffset = $('.sticky-nav').attr('data-sticky-offset');
//        if($(this).scrollTop() > stOffset){
//             $('.sticky-nav').addClass('sticky');
//        }
//        else{
//             $('.sticky-nav').removeClass('sticky');
//        }
        
        $('.sticky-nav').each(function(){
            var stOffset = $(this).attr('data-sticky-offset');
            if($(window).scrollTop() > stOffset){
               $(this).addClass('test');
            }
            else{
                $(this).removeClass('test');
            }
        });
    });
    
    
    
    
    
    if($(".scroll-progress").length > 0){
        document.addEventListener("scroll", updateProgress);
        function updateProgress() {
          var scrollMax = document.body.scrollHeight - window.innerHeight;
          var percentScrolled = window.pageYOffset / scrollMax * 100;
          document.querySelector(".scroll-progress").style.width = percentScrolled + "%";
        }
   }
     $(window).on('load',function () {
        if($('.preloader').length > 0){
           $('.preloader').fadeOut('slow', function () {
                $(this).remove();
            });
        }
    });
    
    //var limitNumber = $(".limit-text").attr('data-text-limit');
    //console.log(limitNumber);
//    $(".limit-text").text(function (index, currentText) {
//        return currentText.substr(0, limitNumber);
//    });
    $(".limit-text").each(function(){
        var limitNumber = $(this).attr('data-text-limit');
        $(this).text(function (index, currentText) {
            return currentText.substr(0, limitNumber);
        });
    });
 
    
    $("[data-smooth-scroll]").on('click', function(event) {
        var scValue = $(this).attr('data-animate-time');
        var hash = this.hash;
        if(!scValue){
           if(hash.length > 0){
                event.preventDefault();
                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 500, function() {
                    window.location.hash = hash;
                });
            }
           }
        if(hash.length > 0){
            event.preventDefault();
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, scValue, function() {
                window.location.hash = hash;
            });
        }
    });
    
$('.offra-countdown').each(function(){
var countContainer = $(this),
    myTimer = countContainer.attr('data-timer-date'),
    countDownDate = new Date(myTimer).getTime(),
    countMessage = countContainer.attr('data-countdown-message'),
    countlabel = $(this).attr('data-countdown-seperator'),


    sTimerfunction = setInterval(function() {
        var cDate = new Date().getTime();
        var Salamdistance = countDownDate - cDate;

        var days = Math.floor(Salamdistance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((Salamdistance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((Salamdistance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((Salamdistance % (1000 * 60)) / 1000);
        if(countlabel == 'dots'){
            countContainer.addClass('countdown-dots');
            countContainer.children(".countdown-days").html(days);
            countContainer.children(".countdown-hours").html(hours);
            countContainer.children(".countdown-minutes").html(minutes);
            countContainer.children(".countdown-seconds").html(seconds);
        }
        if(countlabel == 'label'){
            countContainer.addClass('countdown-label');
            countContainer.children(".countdown-days").html(days).append("<span>days</span>");
            countContainer.children(".countdown-hours").html(hours).append("<span>hours</span>");
            countContainer.children(".countdown-minutes").html(minutes).append("<span>minutes</span>");
            countContainer.children(".countdown-seconds").html(seconds).append("<span>seconds</span>");
        }
        else{
            countContainer.children(".countdown-days").html(days).append("<span>days</span>");
            countContainer.children(".countdown-hours").html(hours).append("<span>hours</span>");
            countContainer.children(".countdown-minutes").html(minutes).append("<span>minutes</span>");
            countContainer.children(".countdown-seconds").html(seconds).append("<span>seconds</span>");
        }
    if (Salamdistance < 0) {
        clearInterval(sTimerfunction);
        countContainer.html(countMessage);
        countContainer.addClass('countdown-finished');
    }
    else{
        countContainer.removeClass('countdown-finished');
    }

    }, 1000);
    });
    
    //Drop Down
    $("[data-target-dropdown]").fadeOut();
    $("[data-activity]").each(function(){
        var status = $(this);
        var stVal = status.attr('data-dropdown-behaviour');
        if(stVal == 'hover'){
           status.on('mouseenter',function(){
                //var elHeight = container.height();
                var acNew = $(this).attr('id');
                $(document).find("[data-target-dropdown='" + acNew + "']").toggleClass('show');
                $(document).find("[data-target-dropdown='" + acNew + "']").fadeToggle();

            }).on('mouseleave',function(){
               //var elHeight = container.height();
                var acNew = $(this).attr('id');
                $(document).find("[data-target-dropdown='" + acNew + "']").removeClass('show');
                $(document).find("[data-target-dropdown='" + acNew + "']").fadeOut();
           });
            $('.offra-dropdown').on('mouseenter',function(){
                var acNew = $(this).attr('id');
                //$(document).find("[data-target-dropdown='" + acNew + "']").toggleClass('show');
                $(document).find("[data-target-dropdown='" + acNew + "']").fadeIn();
            });
        }
        else{
            
        }
        if(stVal == 'click'){
           var container = $(this);
            container.on('click',function(){
                var acNew = $(this).attr('id');
                $(document).find("[data-target-dropdown='" + acNew + "']").toggleClass('show');
                $(document).find("[data-target-dropdown='" + acNew + "']").fadeToggle();

            });
        }
       
        
    });
    
    
        
 })(jQuery);